import React, { useState, useRef } from "react";
import { View, Button } from "react-native";
import { Camera } from "expo-camera";
import api from "../api";

export default function CameraPanel() {
  const [permission, requestPermission] = Camera.useCameraPermissions();
  const [active, setActive] = useState(false);
  const cameraRef = useRef(null);

  const captureAndSend = async () => {
    if (!cameraRef.current) return;
    const photo = await cameraRef.current.takePictureAsync({ base64: false });
    const form = new FormData();
    form.append("image", {
      uri: photo.uri,
      type: "image/jpeg",
      name: "capture.jpg",
    });
    await api.post("/upload-image", form, { headers: { "Content-Type": "multipart/form-data" } });
  };

  if (!permission?.granted) {
    return <Button title="Allow Camera" onPress={requestPermission} />;
  }

  return (
    <View style={{ flex: 1, padding: 10 }}>
      {active && <Camera style={{ flex: 1 }} ref={cameraRef} />}
      <Button title={active ? "Close Camera" : "Open Camera"} onPress={() => setActive(!active)} />
      <Button title="Send Image" onPress={captureAndSend} />
    </View>
  );
}
