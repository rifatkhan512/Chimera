import React, { useState } from "react";
import { View, Text, TextInput, Button, ScrollView } from "react-native";
import api from "../api";
import CameraPanel from "../components/CameraPanel";

export default function ChatScreen() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);

  const sendMessage = async () => {
    try {
      const res = await api.post("/generate", { query: input });
      setMessages([...messages, { role: "user", text: input }, { role: "bot", text: res.data.answer }]);
      setInput("");
    } catch (err) {
      alert("Failed to send message. Check your backend!");
    }
  };

  return (
    <View style={{ flex: 1, flexDirection: "row" }}>
      <View style={{ flex: 2, padding: 10 }}>
        <Text>Describe your problems and progress</Text>
        <ScrollView style={{ height: 300, borderWidth: 1, marginVertical: 10 }}>
          {messages.map((m, i) => (
            <Text key={i} style={{ marginVertical: 3 }}>
              {m.role === "user" ? "You: " : "Bot: "} {m.text}
            </Text>
          ))}
        </ScrollView>
        <TextInput
          placeholder="Type here..."
          value={input}
          onChangeText={setInput}
          style={{ borderWidth: 1, padding: 5 }}
        />
        <Button title="Send" onPress={sendMessage} />
      </View>

      <CameraPanel />
    </View>
  );
}
