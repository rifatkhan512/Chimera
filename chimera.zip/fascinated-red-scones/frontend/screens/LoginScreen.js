import React, { useState } from "react";
import { View, Text, TextInput, Button } from "react-native";
import api from "../api";
import { saveToken } from "../auth";

export default function LoginScreen({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    try {
      const res = await api.post("/token", { username, password });
      await saveToken(res.data.access_token);
      onLogin();
    } catch (err) {
      alert("Login failed. Make sure your backend is running!");
    }
  };

  return (
    <View style={{ padding: 30 }}>
      <Text style={{ fontSize: 22 }}>Login</Text>
      <TextInput
        placeholder="Username"
        style={{ borderWidth: 1, marginVertical: 10, padding: 5 }}
        onChangeText={setUsername}
      />
      <TextInput
        placeholder="Password"
        secureTextEntry
        style={{ borderWidth: 1, marginVertical: 10, padding: 5 }}
        onChangeText={setPassword}
      />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
}
